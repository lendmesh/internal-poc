using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace FindITExpert.Data;

/// <summary>
/// Database context for ASP.NET Identity.
/// Replaces SQL Server Compact (StarterSite.sdf) with SQLite.
/// </summary>
public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }
}
