using Microsoft.AspNetCore.Identity;

namespace FindITExpert.Data;

/// <summary>
/// Application user extending IdentityUser.
/// Replaces the old UserProfile table from SimpleMembership.
/// The Email property is inherited from IdentityUser and serves as the username.
/// </summary>
public class ApplicationUser : IdentityUser
{
}
