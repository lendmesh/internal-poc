using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FindITExpert.Pages;

public class AboutModel : PageModel
{
    public void OnGet()
    {
    }
}
