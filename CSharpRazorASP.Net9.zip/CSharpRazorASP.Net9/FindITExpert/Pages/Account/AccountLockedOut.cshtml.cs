using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FindITExpert.Pages.Account;

public class AccountLockedOutModel : PageModel
{
    public void OnGet()
    {
    }
}
