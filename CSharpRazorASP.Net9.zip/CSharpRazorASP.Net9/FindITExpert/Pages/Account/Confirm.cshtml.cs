using FindITExpert.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FindITExpert.Pages.Account;

public class ConfirmModel : PageModel
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;

    public ConfirmModel(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager)
    {
        _userManager = userManager;
        _signInManager = signInManager;
    }

    [BindProperty(SupportsGet = true)]
    public string? ConfirmationCode { get; set; }

    public string? Message { get; set; }

    public async Task OnGetAsync()
    {
        if (!string.IsNullOrEmpty(ConfirmationCode))
        {
            await ProcessConfirmation();
        }
    }

    public async Task OnPostAsync()
    {
        if (!string.IsNullOrEmpty(ConfirmationCode))
        {
            await ProcessConfirmation();
        }
    }

    private async Task ProcessConfirmation()
    {
        // Sign out current user first (same as old behavior)
        await _signInManager.SignOutAsync();

        // Find user by confirmation token - we need to search all users
        // In the old project, WebSecurity.ConfirmAccount just takes the token directly
        // In ASP.NET Identity, we need the user + token. We'll search by iterating users.
        var users = _userManager.Users.Where(u => !u.EmailConfirmed).ToList();
        foreach (var user in users)
        {
            var result = await _userManager.ConfirmEmailAsync(user, ConfirmationCode!);
            if (result.Succeeded)
            {
                Message = "Registration Confirmed! Click on the log in tab to log in to the site.";
                return;
            }
        }

        Message = "Could not confirm your registration info.";
    }
}
