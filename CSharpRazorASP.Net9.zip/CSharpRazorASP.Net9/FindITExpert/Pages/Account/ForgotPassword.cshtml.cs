using System.ComponentModel.DataAnnotations;
using System.Text.Encodings.Web;
using FindITExpert.Data;
using FindITExpert.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FindITExpert.Pages.Account;

public class ForgotPasswordModel : PageModel
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IEmailSender _emailSender;

    public ForgotPasswordModel(UserManager<ApplicationUser> userManager, IEmailSender emailSender)
    {
        _userManager = userManager;
        _emailSender = emailSender;
    }

    [BindProperty]
    public InputModel Input { get; set; } = new();

    public bool PasswordSent { get; set; }

    public class InputModel
    {
        [Required(ErrorMessage = "The email address field is required.")]
        [EmailAddress]
        [Display(Name = "Email address")]
        public string Email { get; set; } = string.Empty;
    }

    public void OnGet(string? email = null)
    {
        if (!string.IsNullOrEmpty(email))
        {
            Input.Email = email;
        }
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
            return Page();

        var user = await _userManager.FindByEmailAsync(Input.Email);

        // Don't reveal that the user does not exist (same security behavior as old project)
        if (user == null || !await _userManager.IsEmailConfirmedAsync(user))
        {
            PasswordSent = true;
            return Page();
        }

        var token = await _userManager.GeneratePasswordResetTokenAsync(user);
        var resetUrl = Url.Page(
            "/Account/PasswordReset",
            pageHandler: null,
            values: new { resetToken = token, email = Input.Email },
            protocol: Request.Scheme)!;

        await _emailSender.SendEmailAsync(
            Input.Email,
            "Please reset your password",
            $"Use this password reset token to reset your password. The token is: {token}. Visit <a href=\"{HtmlEncoder.Default.Encode(resetUrl)}\">{HtmlEncoder.Default.Encode(resetUrl)}</a> to reset your password.");

        PasswordSent = true;
        return Page();
    }
}
