using System.ComponentModel.DataAnnotations;
using FindITExpert.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FindITExpert.Pages.Account;

public class PasswordResetModel : PageModel
{
    private readonly UserManager<ApplicationUser> _userManager;

    public PasswordResetModel(UserManager<ApplicationUser> userManager)
    {
        _userManager = userManager;
    }

    [BindProperty]
    public InputModel Input { get; set; } = new();

    public bool TokenExpired { get; set; }
    public bool IsSuccess { get; set; }

    public class InputModel
    {
        [Required(ErrorMessage = "The new password field is required.")]
        [StringLength(int.MaxValue, MinimumLength = 6, ErrorMessage = "New password must be at least 6 characters")]
        [DataType(DataType.Password)]
        [Display(Name = "New password")]
        public string NewPassword { get; set; } = string.Empty;

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; } = string.Empty;

        [Required(ErrorMessage = "The password reset token field is required.")]
        [Display(Name = "Password reset token")]
        public string ResetToken { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;
    }

    public void OnGet(string? resetToken = null, string? email = null)
    {
        Input.ResetToken = resetToken ?? string.Empty;
        Input.Email = email ?? string.Empty;
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
            return Page();

        var user = await _userManager.FindByEmailAsync(Input.Email);
        if (user == null)
        {
            // Don't reveal that the user does not exist
            TokenExpired = true;
            return Page();
        }

        var result = await _userManager.ResetPasswordAsync(user, Input.ResetToken, Input.NewPassword);

        if (result.Succeeded)
        {
            IsSuccess = true;
            return Page();
        }

        TokenExpired = true;
        foreach (var error in result.Errors)
        {
            ModelState.AddModelError(string.Empty, error.Description);
        }

        return Page();
    }
}
