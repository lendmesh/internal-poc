using System.ComponentModel.DataAnnotations;
using System.Text.Encodings.Web;
using FindITExpert.Data;
using FindITExpert.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FindITExpert.Pages.Account;

public class RegisterModel : PageModel
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly IEmailSender _emailSender;

    public RegisterModel(
        UserManager<ApplicationUser> userManager,
        SignInManager<ApplicationUser> signInManager,
        IEmailSender emailSender)
    {
        _userManager = userManager;
        _signInManager = signInManager;
        _emailSender = emailSender;
    }

    [BindProperty]
    public InputModel Input { get; set; } = new();

    public class InputModel
    {
        [Required(ErrorMessage = "You must specify an email address.")]
        [EmailAddress]
        [Display(Name = "Email address")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Password cannot be blank.")]
        [StringLength(int.MaxValue, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "Password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; } = string.Empty;
    }

    public void OnGet()
    {
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
            return Page();

        var user = new ApplicationUser
        {
            UserName = Input.Email,
            Email = Input.Email
        };

        var result = await _userManager.CreateAsync(user, Input.Password);

        if (result.Succeeded)
        {
            if (_emailSender.IsConfigured)
            {
                // Generate email confirmation token and send confirmation email
                var token = await _userManager.GenerateEmailConfirmationTokenAsync(user);
                var confirmationUrl = Url.Page(
                    "/Account/Confirm",
                    pageHandler: null,
                    values: new { confirmationCode = token },
                    protocol: Request.Scheme)!;

                await _emailSender.SendEmailAsync(
                    Input.Email,
                    "Please confirm your account",
                    $"Your confirmation code is: {token}. Visit <a href=\"{HtmlEncoder.Default.Encode(confirmationUrl)}\">{HtmlEncoder.Default.Encode(confirmationUrl)}</a> to activate your account.");

                return RedirectToPage("Thanks");
            }

            // No email confirmation required - sign in directly (same as old behavior)
            await _signInManager.SignInAsync(user, isPersistent: false);
            return RedirectToPage("/Index");
        }

        foreach (var error in result.Errors)
        {
            ModelState.AddModelError(string.Empty, error.Description);
        }

        return Page();
    }
}
