using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FindITExpert.Pages.Account;

public class ThanksModel : PageModel
{
    public void OnGet()
    {
    }
}
