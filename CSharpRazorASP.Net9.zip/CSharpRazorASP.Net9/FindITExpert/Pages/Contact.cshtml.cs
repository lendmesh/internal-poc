using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FindITExpert.Pages;

public class ContactModel : PageModel
{
    public void OnGet()
    {
    }
}
