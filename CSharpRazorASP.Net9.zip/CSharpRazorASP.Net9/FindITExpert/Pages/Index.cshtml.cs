using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FindITExpert.Pages;

public class IndexModel : PageModel
{
    public void OnGet()
    {
    }
}
