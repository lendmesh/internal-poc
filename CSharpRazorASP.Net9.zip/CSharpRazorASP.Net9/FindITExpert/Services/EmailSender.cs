using System.Net;
using System.Net.Mail;

namespace FindITExpert.Services;

/// <summary>
/// Email sender service replacing WebMail from the old project.
/// Reads SMTP configuration from appsettings.json EmailSettings section.
/// When SmtpServer is empty, email features are disabled (same behavior as old project).
/// </summary>
public class EmailSender : IEmailSender
{
    private readonly IConfiguration _configuration;

    public EmailSender(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public bool IsConfigured =>
        !string.IsNullOrEmpty(_configuration["EmailSettings:SmtpServer"]);

    public async Task SendEmailAsync(string toEmail, string subject, string htmlMessage)
    {
        if (!IsConfigured)
            throw new InvalidOperationException("SMTP server is not configured.");

        var smtpServer = _configuration["EmailSettings:SmtpServer"]!;
        var smtpPort = int.Parse(_configuration["EmailSettings:SmtpPort"] ?? "587");
        var enableSsl = bool.Parse(_configuration["EmailSettings:EnableSsl"] ?? "true");
        var userName = _configuration["EmailSettings:UserName"]!;
        var password = _configuration["EmailSettings:Password"]!;
        var fromAddress = _configuration["EmailSettings:FromAddress"]!;

        using var client = new SmtpClient(smtpServer, smtpPort)
        {
            Credentials = new NetworkCredential(userName, password),
            EnableSsl = enableSsl
        };

        var mailMessage = new MailMessage(fromAddress, toEmail, subject, htmlMessage)
        {
            IsBodyHtml = true
        };

        await client.SendMailAsync(mailMessage);
    }
}
