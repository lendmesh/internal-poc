namespace FindITExpert.Services;

public interface IEmailSender
{
    bool IsConfigured { get; }
    Task SendEmailAsync(string toEmail, string subject, string htmlMessage);
}
